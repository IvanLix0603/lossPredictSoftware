from PyQt5 import QtWidgets, uic
import sys
from nn import net
import torch
from prepare_data import preprocess

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(MainWindow,self).__init__()
        uic.loadUi("source/main.ui", self)
        #self.window.exit.clicked.connect(app.quit)
        self.model = net()
        self.show()
        self.start.clicked.connect(self.launch)
        ########################
        self.params = {'hyper_thread': 89, 'N':8, 'O1':80, 'O2':9, 'test_number':6 } # Это следующий этап
        #########################

    def launch(self, input_data):
        input_data = self.params
        data = preprocess()
        data['hyper_thread'] = input_data['hyper_thread']
        data['N'] = input_data['N']
        data['O1'] = input_data['O1']
        data['O2'] = input_data['O2']
        data['test_number'] = input_data['test_number']
    
        self.predict(data)
    

    def predict(self, data):
        #load model
        self.model.state_dict(torch.load('saved_model'))
        inputs = self.model.prepare_data_to_nn(data)
        inputs = inputs.type(torch.float32)
        result = self.model.forward(inputs)
        result = str(result.tolist()[0])
        print(result)
        self.output.setText(result)

    
'''
    def check_all(self):
        if self.window.Test_1.isChecked():
            self.test.append("1")
        if self.window.Test_2.isChecked():
            self.test.append("2")
        if self.window.Test_3.isChecked():
            self.test.append("3")
        if  self.window.Test_4.isChecked():
            self.test.append("4")
        if  self.window.btn_25el.isChecked():
            self.elements.append("25")
        if  self.window.btn_50el.isChecked():
            self.elements.append("50")
        if  self.window.btn_100el.isChecked():
            self.elements.append("100")
        if  self.window.btn_150el.isChecked():
            self.elements.append("150")
        if  self.window.btn_200el.isChecked():
            self.elements.append("200")
        if  self.window.btn_300el.isChecked():
            self.elements.append("300")
        if  self.window.btn_500el.isChecked():
            self.elements.append("500")
        if  self.window.btn_1000el.isChecked():
            self.elements.append("1000")
        if  self.window.btn_1200el.isChecked():
            self.elements.append("1200")
        print(self.test, self.elements)
        manage(self.test, self.manage)
    '''

if __name__ =="__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow()
    app.exec_()



