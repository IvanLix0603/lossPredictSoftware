#!/bin/bash
echo "1_test:"
cd 1_test;bash scr2.sh;cd ..
echo "2_test:"
cd 2_test;bash scr2.sh;cd ..
echo "3_test:"
cd 3_test;bash scr2.sh;cd ..
echo "4_test:"
cd 4_test;bash scr2.sh;cd ..
